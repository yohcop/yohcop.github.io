#! /usr/bin/env python
# -*- coding: utf-8 -*-
import sys, os, tempfile

density=600
imagesize=1024

def r(c):
  print c
  os.system(c)

def main(input, output):
  dir = tempfile.mktemp("_odp", "pdf2odp_", tempfile.gettempdir())
  print dir
  r("unzip -d %s template.odp" % dir)

  r("convert -density %sx%s -resize %sx%s %s %s/Pictures/background.png" %
      (density, density, imagesize, imagesize, input, dir))

  files = os.listdir("%s/Pictures/" % dir)
  list = ["background-%s.png" % i for i in range(len(files))]
  print list

  createStyles(dir, list)
  createContent(dir, list)
  r("cd %s && zip -r %s.odp *" % (dir, output))
  print "====="
  print "Your ODP file is here: %s/%s.odp" % (dir, output)
  #r("rm -rf %s" % dir)

def createStyles(dir, list):
  out = open("%s/styles.xml" % dir, 'w+')
  head = open("%s/styles_head.xml" % dir)
  out.write(head.read())
  head.close()
  for b in list:
    out.write("""<draw:fill-image draw:name="%s" xlink:href="Pictures/%s" xlink:type="simple" xlink:show="embed" xlink:actuate="onLoad"/>""" % (b[:-4], b))
  tail = open("%s/styles_tail.xml" %  dir)
  out.write(tail.read())
  tail.close()
  out.close()

def createContent(dir, list):
  out = open("%s/content.xml" % dir, 'w+')
  head = open("%s/content_head.xml" % dir)
  out.write(head.read())
  head.close()
  out.write("""<office:automatic-styles>""")
  for b in list:
    out.write("""
    <style:style style:name="%s" style:family="drawing-page">
      <style:drawing-page-properties presentation:background-visible="true" presentation:background-objects-visible="true" draw:fill="bitmap" draw:fill-image-name="%s" style:repeat="stretch"/>
    </style:style>
    """ % (b[:-4], b[:-4]))
  out.write("""</office:automatic-styles>""")

  out.write("""
    <office:body>
      <office:presentation>""")
  for b in list:
    out.write("""
        <draw:page draw:name="%s" draw:style-name="%s" draw:master-page-name="Default"/>""" % (b[:-4], b[:-4]))

  out.write("""
      </office:presentation>
    </office:body>""")

  tail = open("%s/content_tail.xml" %  dir)
  out.write(tail.read())
  tail.close()
  out.close()

if __name__ == "__main__":
  #sys.argv
  if len(sys.argv) != 3:
    print "Usage:"
    print "  %s input.pdf output" % sys.argv[0]
  else:
    main(sys.argv[1], sys.argv[2])

